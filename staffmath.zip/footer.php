    <footer>
	    <div class="wrapper">
	        <div class="copyright">
	            BETA VERSION | by Fathur Rachman Widhiantoko
	        </div>
	    </div>
	</footer>
   
    <script src="user/js/jquery-1.11.1.min.js" type="text/javascript"></script>
    <script src="user/js/frontpage.js" type="text/javascript"></script>