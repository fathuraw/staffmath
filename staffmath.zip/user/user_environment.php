<?php
    require_once('session.php');
    sessioncheck();
    
    /*$userid=$_SESSION['SESS_USER_ID'];
    require_once('config.php');
    $qry="SELECT profilepicture, user_nickname FROM users WHERE user_id=$userid";
    $result=mysql_query($qry);
    $member = mysql_fetch_assoc($result); */
?>